<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esqueci a Senha - ConectTecs</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <main>
        <div class="reset-container">
            <h2>ESTÁ OPÇÃO ESTARÁ DISPONIVEL EM BREVE</h2>
        </div>
    </main>
</body>
</html>
