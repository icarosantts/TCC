<?php
use PHPUnit\Framework\TestCase;

class Esqueci_senhaTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../esqueci_senha.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
