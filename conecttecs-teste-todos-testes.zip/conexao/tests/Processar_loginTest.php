<?php
use PHPUnit\Framework\TestCase;

class Processar_loginTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../processar_login.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
