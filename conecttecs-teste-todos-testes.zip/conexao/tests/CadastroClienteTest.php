<?php
use PHPUnit\Framework\TestCase;

class CadastroClienteTest extends TestCase {
    public function testCadastroComDadosValidos() {
        $_POST['nome'] = 'João da Silva';
        $_POST['email'] = 'joao@example.com';
        $_POST['senha'] = 'senha123';

        ob_start();
        include __DIR__ . '/../cadastro_cliente.php';
        $output = ob_get_clean();

        $this->assertStringNotContainsString('erro', $output);
    }
}
