<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../alterar_email.php';

class AlterarEmailTest extends TestCase {
    public function testAlterarEmailValido() {
        $this->assertTrue(alterarEmail('teste@teste.com', 'novo@email.com'));
    }

    public function testAlterarEmailInvalido() {
        $this->assertFalse(alterarEmail('teste@teste.com', 'email-invalido'));
    }
}
