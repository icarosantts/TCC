<?php
use PHPUnit\Framework\TestCase;

class LogoutTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../logout.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
