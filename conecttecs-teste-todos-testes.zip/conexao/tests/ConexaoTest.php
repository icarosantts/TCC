<?php
use PHPUnit\Framework\TestCase;

class ConexaoTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../conexao.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
