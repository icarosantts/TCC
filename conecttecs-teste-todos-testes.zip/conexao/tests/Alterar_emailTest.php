<?php
use PHPUnit\Framework\TestCase;

class Alterar_emailTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../alterar_email.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
