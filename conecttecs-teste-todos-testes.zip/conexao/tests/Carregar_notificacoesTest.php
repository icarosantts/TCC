<?php
use PHPUnit\Framework\TestCase;

class Carregar_notificacoesTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../carregar_notificacoes.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
