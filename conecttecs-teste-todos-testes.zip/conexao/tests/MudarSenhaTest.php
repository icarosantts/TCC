<?php
use PHPUnit\Framework\TestCase;

class MudarSenhaTest extends TestCase {
    public function testMudarSenhaComDadosValidos() {
        $_POST['senha_antiga'] = 'senha123';
        $_POST['nova_senha'] = 'novaSenha123';

        ob_start();
        include __DIR__ . '/../mudar-senha.php';
        $output = ob_get_clean();

        $this->assertStringNotContainsString('erro', $output);
    }
}
