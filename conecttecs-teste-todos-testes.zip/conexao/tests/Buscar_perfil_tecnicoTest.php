<?php
use PHPUnit\Framework\TestCase;

class Buscar_perfil_tecnicoTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../buscar-perfil-tecnico.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
