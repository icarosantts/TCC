<?php
use PHPUnit\Framework\TestCase;

class Carregar_mensagensTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../carregar_mensagens.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
