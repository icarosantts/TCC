<?php
use PHPUnit\Framework\TestCase;

class Excluir_conta_clienteTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../excluir_conta_cliente.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
