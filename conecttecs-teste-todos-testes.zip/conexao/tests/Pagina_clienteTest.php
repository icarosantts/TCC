<?php
use PHPUnit\Framework\TestCase;

class Pagina_clienteTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../pagina-cliente.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
