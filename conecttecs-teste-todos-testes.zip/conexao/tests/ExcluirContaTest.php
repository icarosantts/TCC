<?php
use PHPUnit\Framework\TestCase;

class ExcluirContaTest extends TestCase {
    public function testExcluirContaSimples() {
        $_POST['id'] = 1;

        ob_start();
        include __DIR__ . '/../excluir_conta.php';
        $output = ob_get_clean();

        $this->assertStringNotContainsString('erro', $output);
    }
}
