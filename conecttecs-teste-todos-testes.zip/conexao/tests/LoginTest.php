<?php
use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase {
    public function testLoginComDadosValidos() {
        $_POST['email'] = 'teste@exemplo.com';
        $_POST['senha'] = 'senha123';

        ob_start();
        include __DIR__ . '/../processar_login.php';
        $output = ob_get_clean();

        $this->assertStringNotContainsString('erro', $output);
    }
}
