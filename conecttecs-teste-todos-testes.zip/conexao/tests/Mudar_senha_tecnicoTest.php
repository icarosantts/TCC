<?php
use PHPUnit\Framework\TestCase;

class Mudar_senha_tecnicoTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../mudar_senha_tecnico.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
