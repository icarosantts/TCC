<?php
use PHPUnit\Framework\TestCase;

class Cadastro_tecnicoTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../cadastro_tecnico.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
