<?php
use PHPUnit\Framework\TestCase;

class Processar_quizTest extends TestCase {
    public function testIncludeScript() {
        $_POST = [];
        $_GET = [];
        $_SESSION = [];

        ob_start();
        include __DIR__ . '/../processar_quiz.php';
        $output = ob_get_clean();

        $this->assertIsString($output);
    }
}
