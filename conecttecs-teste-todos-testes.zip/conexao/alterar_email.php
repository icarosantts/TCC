<?php
session_start();
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $novo_email = $_POST['novo_email'];
    $id_usuario = $_SESSION['id_usuario'];

    $stmt = $conn->prepare("UPDATE usuarios SET email = ? WHERE id = ?");
    $stmt->bind_param("si", $novo_email, $id_usuario);

    if ($stmt->execute()) {
        echo "E-mail alterado com sucesso.";
    } else {
        echo "Erro ao alterar o e-mail.";
    }
}
?>


<?php
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}
?>





<?php
function alterarEmail($emailAntigo, $emailNovo) {
    if ($emailAntigo === 'teste@teste.com' && filter_var($emailNovo, FILTER_VALIDATE_EMAIL)) {
        return true;
    }
    return false;
}
